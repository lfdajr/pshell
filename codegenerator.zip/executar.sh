cd dist
java -cp ".:PlenoShell.jar" pshell.Main
cd ..

